#!/bin/bash
echo "hello world"

#### PATH DEDINITION ####
LIBNAME="final"
CELLNAME="Question2"
CELLVIEWNAME="config"

pwd="/home/undergrad18/wangyining/Under19"

IWAVE_FILE="iwave.log"
TCL_FILE="calculated.tcl"

DIR_RESULT="${pwd}/${LIBNAME}/Simulation/${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}_ALPS"
NETLIST_FILE="${DIR_RESULT}/${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}.netlist"
NETLIST_MAPPING_FILE="${DIR_RESULT}/${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}.netlist.map"
SP_FILE="${DIR_RESULT}/${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}_Nominal.sp"
SPLOG_FILE="${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}_Nominal.sp.log"

config_temp_FILE="${pwd}/${LIBNAME}/${CELLNAME}/${CELLVIEWNAME}/mmsim_temp.ini"
config_FILE="${pwd}/${LIBNAME}/${CELLNAME}/${CELLVIEWNAME}/mmsim.ini"
NAME_LIST="${pwd}/Namelist.txt"

RESULT_FILE="result_Question2.csv"



#### PARAMETERS DEFINITION ####
NOISE_TAG="integral value of noise from 1.0000hz to 1.0000e+10hz"

NOISE_SEARCH_TAG=0
Power_SEARCH_FLAG=0
NMOS_FLAG="MNM"
PMOS_FLAG="MPM"

DC_GAIN_DB=0
GWB=0
PM=0
NOISE_OUTPUT=0
POWER=0

NBULK_TAG=0
PBULK_TAG=0

NUM_S=0
NUM_L=0
NUM_C=0

i=0

#### Function Definition ####
function updateconfig {
    echo ${1}
    cat ${config_temp_FILE} > ${config_FILE}
    echo "${LIBNAME}\\Answer2=\"schematic_${1};;\"" >> ${config_FILE} # change the config
	
    # cat ${output_FILE}
}


echo "Index, Name, DC_GAIN(dB), GBW(Hz), Phase_Margin(deg), Power(W), Noise(Vrms), Saturation, Linear, Cutoff, Nbulk_error, Pbulk_error" >> ${RESULT_FILE}

while read name
	do 
    USR=${name%_*}


    #### update config
    updateconfig ${name}

    let i++

    #### generate netlist 
    oa2netlist ${LIBNAME} ${CELLNAME} ${CELLVIEWNAME} -t mhspice -o ${NETLIST_FILE} \
        -mf ${NETLIST_MAPPING_FILE} -hier -disp -name keep -max 80 \
        -ntlviewlist hspiceText hspiceD spice schematic veriloga -ntlstoplist hspiceText hspiceD spice \
        -glo -as0 -ael -suf -noexclam -pow "VDD! VCC! VEE! vdd! vcc!" -gnd "GND! GROUND! gnd! vss!" -end \
        -cir : -quo single -del '<' -exprquo quotation -gsub -busBitFormat bracket -printMFactor


    #### run simulation with ALPS
    alps -mde  ${SP_FILE}

    #### run calculator in iwave
    iwave -tcl ${TCL_FILE}

	#### GBW PM DC_GAIN ####
    while read line 
	# Open iwave.log to get the result of calculations

    do
        if [[ ${line:0:4} == "calc" ]]
        then
            line_pro=${line#* }
            case ${line_pro%%(*} in
                "max")
                    if [[ ${line_pro:4:2} == "db" ]]
                    then
                        DC_GAIN_DB=${line##*:}
                        echo "DC_GAIN_DB: ${DC_GAIN_DB} dB" 
                    else
                        GBW=${line##*:}
                        echo "GBW: ${GBW} Hz" 
                    fi
                    ;;        
                "phase_m")
                    PM=${line##*:}
                    echo "PHASE_MARGIN: ${PM} deg" 
                    ;;
            esac
        fi
    done < ${IWAVE_FILE}

#### Power Noise ####

    while read line
	# open .sp.log to get the results of OP and Noise analysis
    do
        if [[ ${Power_SEARCH_TAG} -eq 1 ]]
        then 
            # echo "Power_Flag==1"

            if [[ ${line:0:3} == "pwr" ]]
            then
                # echo "find pwr"
                pwr=${line% 0.0*}
                POWER=${pwr#* }
                echo "Power: ${POWER} W"

                let Power_SEARCH_TAG++
            fi

        else
            # echo ${Power_FLAG} ${line#* *}
            if [[ ${line#* *} == "vsourceDc:" ]]
            then
                # echo "find VsourceDC"
                let Power_SEARCH_TAG=1
            fi
        fi


        if [[ ${NOISE_SEARCH_TAG} -eq 1 ]]
        then 
            if [[ ${line#*output} != ${line} ]]
            then   
                NOISE_OUTPUT=${line#* = };NOISE_OUTPUT=${NOISE_OUTPUT%% *}
                echo "Output Noise: ${NOISE_OUTPUT} Vrms"
                let NOISE_SEARCH_TAG++
            fi
        else
            if [[ ${line#* } == ${NOISE_TAG} ]]
            then
                # echo "Find NOISE"
                let NOISE_SEARCH_TAG++
            fi
        fi

    done < ${SPLOG_FILE}

	#### Check Bulk ####

    while read line
	# Open the .netlist to get the parameters of the MOSFET
    do
        if [[ ${line:0:3} == ${PMOS_FLAG} ]]
        then
            line=${line% p18*}
            PBULK=${line##* }
            line=${line% *}
            PSOURCE=${line##* }
            if [[ ${PBULK} != ${PSOURCE} ]]
            then
                let PBULK_TAG=1
            fi
        fi
        if [[ ${line:0:3} == ${NMOS_FLAG} ]]
        then
            line=${line% n18*}
            NBULK=${line##* }
            # echo ${NBULK}
            if [[ ${NBULK} != "gnda" ]]
            then 
                let NBULK_TAG=1
            fi 
        fi
 
    done < ${NETLIST_FILE}
    let BULK_ERROR=NBULK_TAG+PBULK_TAG
    if [[ ${BULK_ERROR} -eq 0 ]]
    then
        echo "Normal"
    else
        echo "ERROR: ${NBULK_TAG}, ${PBULK_TAG}"
    fi
	NUM_S=$(awk -v RS="@#$j" '{print gsub(/Saturati/,"$")}' final_Question2_config_Nominal.sp.log)
	NUM_L=$(awk -v RS="@#$j" '{print gsub(/Linear/,"$")}' final_Question2_config_Nominal.sp.log)
	NUM_C=$(awk -v RS="@#$j" '{print gsub(/Cutoff/,"$")}' final_Question2_config_Nominal.sp.log)
	echo "${i}, ${USR}, ${DC_GAIN_DB}, ${GBW}, ${PM}, ${POWER}, ${NOISE_OUTPUT}, ${NUM_S}, ${NUM_L}, ${NUM_C}, ${NBULK_TAG}, ${PBULK_TAG}" >> ${RESULT_FILE}

	## reset
    let NOISE_SEARCH_TAG=0
    let Power_SEARCH_TAG=0
	let NBULK_TAG=0
	let PBULK_TAG=0
	let NOISE_OUTPUT=0
    let Power=0
 	let GBW=0
    let DC_GAIN_DB=0
    let PM=0
	let NUM_S=0
	let NUM_L=0
	let NUM_C=0
	
done < ${NAME_LIST}
	echo "ALL DONE"


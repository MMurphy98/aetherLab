#!/bin/bash
echo "hello world"

#### PATH DEDINITION ####
LIBNAME="final"
CELLNAME="Question1"
CELLVIEWNAME="config"

pwd="/home/undergrad18/wangyining/Under19/simulation"

IWAVE_FILE="iwave.log"
TCL_FILE="iwave_q102.tcl"

DIR_RESULT="${pwd}/${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}_ALPS"
NETLIST_FILE="${DIR_RESULT}/${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}.netlist"
NETLIST_MAPPING_FILE="${DIR_RESULT}/${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}.netlist.map"
SP_FILE="${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}_Nominal.sp"
SPRINT_FILE="${LIBNAME}_${CELLNAME}_${CELLVIEWNAME}_Nominal.sp.log"
config_temp_FILE="${LIBNAME}/${CELLNAME}/${CELLVIEWNAME}/mmsim_temp.ini"
config_FILE="${LIBNAME}/${CELLNAME}/${CELLVIEWNAME}/mmsim.ini"
NAME_LIST="Namelist.txt"

RESULT_FILE="result_Question1_2.csv"

BW=0
Iout_AC=0
IOUT_TAG=0
CNT=0

#### Function Definition ####
function updateconfig {
    echo ${1}
    cat ${config_temp_FILE} > ${config_FILE}
    echo "${LIBNAME}\\Answer1=\"schematic_${1};;\"" >> ${config_FILE} # change the config
	
    # cat ${output_FILE}
}


echo "Index, Name, Iout_AC, Bandwidth (Hz)" >> ${RESULT_FILE}

while read name
	do 
    USR=${name%_*}


    #### update config
    updateconfig ${name}

    let CNT++

    #### generate netlist 
    oa2netlist ${LIBNAME} ${CELLNAME} ${CELLVIEWNAME} -t mhspice -o ${NETLIST_FILE} \
        -mf ${NETLIST_MAPPING_FILE} -hier -disp -name keep -max 80 \
        -ntlviewlist hspiceText hspiceD spice schematic veriloga -ntlstoplist hspiceText hspiceD spice \
        -glo -as0 -ael -suf -noexclam -pow "VDD! VCC! VEE! vdd! vcc!" -gnd "GND! GROUND! gnd! vss!" -end \
        -cir : -quo single -del '<' -exprquo quotation -gsub -busBitFormat bracket -printMFactor


    #### run simulation with ALPS
    alps -mde  ${SP_FILE}

    #### run calculator in iwave
    iwave -tcl ${TCL_FILE}

	#### GBW PM DC_GAIN ####
    while read line 
	# Open iwave.log to get the result of calculations

    do
        if [[ ${line:0:4} == "calc" ]]
        then
            line_pro=${line#* }
            case ${line_pro%%(*} in
  
                "cross")
                    BW=${line##*:}
                    echo "Bandwidth: ${BW} Hz" 
                    ;;
            esac
        fi
    done < ${IWAVE_FILE}

	#### Check Iout at 1 Hz ####
	
	while read line
	do
		for i in ${line}; do
			if [[ ${i} == "1.0000" ]]
			then
				let IOUT_TAG++
				echo "Find 1Hz"
			fi
		done
		if [[ ${IOUT_TAG} -eq 1 ]]
		then
				Iout_AC=${i}
				break
		fi

	done < ${SPRINT_FILE}

	echo "${CNT}, ${USR}, ${Iout_AC}, ${BW}" >> ${RESULT_FILE}

	## reset
	let BW=0
	let IOUT_TAG=0
	let Iout_AC=0

done < ${NAME_LIST}
	echo "ALL DONE"

